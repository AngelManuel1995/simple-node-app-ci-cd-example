# Jenkins docker
* Jenkins CI with docker client
